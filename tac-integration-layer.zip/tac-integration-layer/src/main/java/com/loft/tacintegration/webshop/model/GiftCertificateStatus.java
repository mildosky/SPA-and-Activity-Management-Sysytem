package com.loft.tacintegration.webshop.model;

public enum GiftCertificateStatus {
    PENDING_PAYMENT,
    ACTIVE,
    REDEEMED,
    EXPIRED,
    CANCELLED
}
