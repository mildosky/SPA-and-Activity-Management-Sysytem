package com.loft.tacintegration.webshop.web;

import com.loft.tacintegration.webshop.model.GiftCertificate;
import com.loft.tacintegration.webshop.model.GiftCertificateStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record GiftCertificateResponse(
        String code,
        BigDecimal amount,
        String currency,
        String recipientName,
        String recipientEmail,
        GiftCertificateStatus status,
        LocalDateTime expiresAt
) {
    public static GiftCertificateResponse from(GiftCertificate certificate) {
        return new GiftCertificateResponse(
                certificate.getCode(),
                certificate.getAmount(),
                certificate.getCurrency(),
                certificate.getRecipientName(),
                certificate.getRecipientEmail(),
                certificate.getStatus(),
                certificate.getExpiresAt()
        );
    }
}
