package com.loft.tacintegration.pos.model;

public enum ChargeType {
    BOOKING,
    RETAIL_SALE
}
