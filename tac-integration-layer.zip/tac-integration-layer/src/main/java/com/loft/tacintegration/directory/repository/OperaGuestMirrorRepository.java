package com.loft.tacintegration.directory.repository;

import com.loft.tacintegration.directory.model.OperaGuestMirror;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface OperaGuestMirrorRepository extends JpaRepository<OperaGuestMirror, Long> {
    Optional<OperaGuestMirror> findByOperaNameId(String operaNameId);

    /** Case-insensitive — email casing shouldn't be the reason a match fails. */
    Optional<OperaGuestMirror> findByEmailIgnoreCase(String email);
}
