package com.loft.tacintegration.pos.repository;

import com.loft.tacintegration.pos.model.PosSale;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PosSaleRepository extends JpaRepository<PosSale, Long> {
}
